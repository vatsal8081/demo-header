<template>
  <div>
    <div>
      <appHeader></appHeader>
    </div>
  </div>
  <!-- <Tutorial /> -->
</template>

<script>
import appHeader from '@/components/header/header.vue'

export default {
  components: { appHeader },
  data () {
    return {}
  }
}
</script>

<style scoped>
@import url("./style.css");
</style>
